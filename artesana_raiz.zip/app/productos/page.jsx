"use client"
import { useState } from "react"
import { useSearchParams } from "next/navigation"
import ProductCard from "@/components/product-card"
import { ChevronDown } from "lucide-react"

// Datos de ejemplo para los productos
const productsData = [
  {
    id: 1,
    title: "Principito De Plata Y Double De Oro",
    description: "Principito y rosa trabajado en plata925 con detalles en double de oro. Incluye cadena y estuche",
    guarantee: "30 días",
    price: 40000,
    image: "/imagenes/joyas.png",
    category: "joyas",
  },
  {
    id: 2,
    title: "Oso de Peluche Artesanal",
    description: "Oso de peluche hecho a mano con materiales de alta calidad. Ideal para regalo.",
    guarantee: "30 días",
    price: 25000,
    image: "/imagenes/oso.png",
    category: "juguetes",
  },
  {
    id: 3,
    title: "Bolso Tejido a Mano",
    description: "Bolso tejido a mano con hilo de algodón. Diseño único y resistente.",
    guarantee: "30 días",
    price: 35000,
    image: "/imagenes/bolso.png",
    category: "bolsos",
  },
  {
    id: 4,
    title: "Collar de Plata con Piedras",
    description: "Collar de plata 925 con piedras semipreciosas. Diseño exclusivo.",
    guarantee: "30 días",
    price: 45000,
    image: "/imagenes/joyas.png",
    category: "joyas",
  },
  {
    id: 5,
    title: "Muñeca de Trapo Artesanal",
    description: "Muñeca de trapo hecha a mano con telas de algodón. Ideal para niños.",
    guarantee: "30 días",
    price: 20000,
    image: "/imagenes/oso.png",
    category: "juguetes",
  },
  {
    id: 6,
    title: "Mochila Tejida Artesanal",
    description: "Mochila tejida a mano con hilo de algodón. Diseño único y resistente.",
    guarantee: "30 días",
    price: 38000,
    image: "/imagenes/bolso.png",
    category: "bolsos",
  },
]

export default function ProductsPage() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams.get("categoria")

  const [categoryDropdown, setCategoryDropdown] = useState(false)
  const [priceDropdown, setPriceDropdown] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState(categoryParam || "todos")
  const [sortByPrice, setSortByPrice] = useState("default")

  const toggleCategoryDropdown = () => setCategoryDropdown(!categoryDropdown)
  const togglePriceDropdown = () => setPriceDropdown(!priceDropdown)

  const handleCategorySelect = (category) => {
    setSelectedCategory(category)
    setCategoryDropdown(false)
  }

  const handlePriceSort = (sort) => {
    setSortByPrice(sort)
    setPriceDropdown(false)
  }

  // Filtrar y ordenar productos
  let filteredProducts = [...productsData]

  if (selectedCategory !== "todos") {
    filteredProducts = filteredProducts.filter((product) => product.category === selectedCategory)
  }

  if (sortByPrice === "asc") {
    filteredProducts.sort((a, b) => a.price - b.price)
  } else if (sortByPrice === "desc") {
    filteredProducts.sort((a, b) => b.price - a.price)
  }

  return (
    <div className="container-custom">
      <h1 className="section-title">Productos</h1>

      {/* Filtros */}
      <div className="flex flex-col md:flex-row justify-center gap-4 mb-8">
        <div className="relative">
          <button
            className="flex items-center justify-between w-full md:w-48 px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm"
            onClick={toggleCategoryDropdown}
          >
            <span>
              {selectedCategory === "todos"
                ? "Todas las categorías"
                : selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}
            </span>
            <ChevronDown size={16} />
          </button>

          {categoryDropdown && (
            <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg">
              <ul>
                <li
                  className="px-4 py-2 hover:bg-amber-100 cursor-pointer"
                  onClick={() => handleCategorySelect("todos")}
                >
                  Todas las categorías
                </li>
                <li
                  className="px-4 py-2 hover:bg-amber-100 cursor-pointer"
                  onClick={() => handleCategorySelect("juguetes")}
                >
                  Juguetes
                </li>
                <li
                  className="px-4 py-2 hover:bg-amber-100 cursor-pointer"
                  onClick={() => handleCategorySelect("joyas")}
                >
                  Joyas
                </li>
                <li
                  className="px-4 py-2 hover:bg-amber-100 cursor-pointer"
                  onClick={() => handleCategorySelect("bolsos")}
                >
                  Bolsos
                </li>
              </ul>
            </div>
          )}
        </div>

        <div className="relative">
          <button
            className="flex items-center justify-between w-full md:w-48 px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm"
            onClick={togglePriceDropdown}
          >
            <span>
              {sortByPrice === "default"
                ? "Ordenar por precio"
                : sortByPrice === "asc"
                  ? "Precio: menor a mayor"
                  : "Precio: mayor a menor"}
            </span>
            <ChevronDown size={16} />
          </button>

          {priceDropdown && (
            <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg">
              <ul>
                <li className="px-4 py-2 hover:bg-amber-100 cursor-pointer" onClick={() => handlePriceSort("default")}>
                  Predeterminado
                </li>
                <li className="px-4 py-2 hover:bg-amber-100 cursor-pointer" onClick={() => handlePriceSort("asc")}>
                  Precio: menor a mayor
                </li>
                <li className="px-4 py-2 hover:bg-amber-100 cursor-pointer" onClick={() => handlePriceSort("desc")}>
                  Precio: mayor a menor
                </li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Grilla de productos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map((product) => (
          <ProductCard
            key={product.id}
            id={product.id}
            title={product.title}
            price={product.price}
            image={product.image}
          />
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-10">
          <p className="text-lg">No se encontraron productos en esta categoría.</p>
        </div>
      )}
    </div>
  )
}
