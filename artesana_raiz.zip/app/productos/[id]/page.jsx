"use client"
import { useState, useEffect } from "react"
import Image from "next/image"
import { useParams } from "next/navigation"
import { ShoppingBag } from "lucide-react"

// Datos de ejemplo para los productos
const productsData = [
  {
    id: 1,
    title: "Principito De Plata Y Double De Oro",
    description: "Principito y rosa trabajado en plata925 con detalles en double de oro. Incluye cadena y estuche",
    guarantee: "30 días",
    price: 40000,
    image: "/imagenes/joyas.png",
    category: "joyas",
  },
  {
    id: 2,
    title: "Oso de Peluche Artesanal",
    description: "Oso de peluche hecho a mano con materiales de alta calidad. Ideal para regalo.",
    guarantee: "30 días",
    price: 25000,
    image: "/imagenes/oso.png",
    category: "juguetes",
  },
  {
    id: 3,
    title: "Bolso Tejido a Mano",
    description: "Bolso tejido a mano con hilo de algodón. Diseño único y resistente.",
    guarantee: "30 días",
    price: 35000,
    image: "/imagenes/bolso.png",
    category: "bolsos",
  },
  {
    id: 4,
    title: "Collar de Plata con Piedras",
    description: "Collar de plata 925 con piedras semipreciosas. Diseño exclusivo.",
    guarantee: "30 días",
    price: 45000,
    image: "/imagenes/joyas.png",
    category: "joyas",
  },
  {
    id: 5,
    title: "Muñeca de Trapo Artesanal",
    description: "Muñeca de trapo hecha a mano con telas de algodón. Ideal para niños.",
    guarantee: "30 días",
    price: 20000,
    image: "/imagenes/oso.png",
    category: "juguetes",
  },
  {
    id: 6,
    title: "Mochila Tejida Artesanal",
    description: "Mochila tejida a mano con hilo de algodón. Diseño único y resistente.",
    guarantee: "30 días",
    price: 38000,
    image: "/imagenes/bolso.png",
    category: "bolsos",
  },
]

export default function ProductDetailPage() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simular carga de datos
    const productId = Number.parseInt(id)
    const foundProduct = productsData.find((p) => p.id === productId)

    if (foundProduct) {
      setProduct(foundProduct)
    }

    setLoading(false)
  }, [id])

  if (loading) {
    return (
      <div className="container-custom flex justify-center items-center min-h-[50vh]">
        <p className="text-xl">Cargando producto...</p>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container-custom flex justify-center items-center min-h-[50vh]">
        <p className="text-xl">Producto no encontrado</p>
      </div>
    )
  }

  return (
    <div className="container-custom py-10">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {/* Imagen del producto */}
        <div className="relative h-[400px] md:h-[500px] rounded-lg overflow-hidden">
          <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
        </div>

        {/* Información del producto */}
        <div className="flex flex-col">
          <h1 className="text-2xl md:text-3xl font-bold text-amber-900 mb-4">{product.title}</h1>
          <p className="text-2xl font-bold text-amber-700 mb-6">${product.price.toLocaleString()}</p>

          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold mb-3">Descripción</h2>
            <p className="text-gray-700 mb-4">{product.description}</p>

            <h2 className="text-xl font-semibold mb-3">Garantía</h2>
            <p className="text-gray-700">{product.guarantee}</p>
          </div>

          <button className="btn-primary flex items-center justify-center gap-2 py-3 mt-auto">
            <ShoppingBag size={20} />
            Comprar
          </button>
        </div>
      </div>
    </div>
  )
}
